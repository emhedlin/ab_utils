
from abc import ABC, abstractmethod

class AbstractDistribution(ABC):
    def __init__(self, total_samples, proportion_treated):
        self.total_samples = total_samples
        self.num_samples_treatment = int(total_samples * proportion_treated)
        self.num_samples_baseline = total_samples - self.num_samples_treatment

    @abstractmethod
    def simulate_data(self):
        pass

    @abstractmethod
    def analysis(self, baseline_data, treatment_data, *args, **kwargs):
        """
        Perform Bayesian analysis on the given data and return the posteriors for the baseline and treatment.
        """
        pass

    def simulated_runs(self, n_runs, *args, **kwargs):
        """
        Run the analysis method multiple times and return the number of times
        the 90% credible interval of the difference between the treatment and baseline
        posteriors does not overlap zero.

        Args:
            n_runs (int): The number of times to run the analysis method.
            *args, **kwargs: Any additional arguments and keyword arguments that should be
                             passed to the analysis method.

        Returns:
            int: The number of times the 90% credible interval of the difference between
                 the treatment and baseline posteriors does not overlap zero.
        """
        true_directional_results_count = 0

        for _ in range(n_runs):
            baseline_data, treatment_data = self.simulate_data()
            posterior_baseline, posterior_treatment = self.analysis(baseline_data, treatment_data, *args, **kwargs)

            # Calculate the 90% credible intervals for the posteriors.
            lower_bound_baseline, upper_bound_baseline = self.calculate_credible_interval(posterior_baseline)
            lower_bound_treatment, upper_bound_treatment = self.calculate_credible_interval(posterior_treatment)

            # Check if the credible intervals do not overlap zero.
            if lower_bound_treatment - upper_bound_baseline > 0:
                true_directional_results_count += 1

        return true_directional_results_count

    @abstractmethod
    def calculate_credible_interval(self, posterior, alpha=0.9):
        """
        Calculate the credible interval for the given posterior distribution and alpha level.

        Args:
            posterior: The posterior distribution. This can be any object that the specific
                       distribution's implementation of this method can work with.
            alpha (float): The alpha level for the credible interval, default is 0.9 for a 90% interval.

        Returns:
            tuple: The lower and upper bounds of the credible interval for the posterior.
        """
        pass
