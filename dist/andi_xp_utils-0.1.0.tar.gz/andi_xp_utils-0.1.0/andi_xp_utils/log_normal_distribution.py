import numpy as np
from scipy.stats import invgamma, t
from abstract_distribution import AbstractDistribution



class LogNormalDistribution(AbstractDistribution):
    """
    A class representing a Bayesian A/B test with log-normal distributed outcomes
    (e.g., revenue per session or other continuous, positive data).

    This class is a subclass of the AbstractDistribution class and implements a Bayesian analysis
    using the Normal-Gamma conjugate prior for log-normal data.

    Attributes:
        total_samples (int): The total number of samples in the experiment.
        proportion_treated (float): The proportion of samples in the treatment group.
        mu_baseline (float): The mean of the log-normal distribution for the baseline group.
        sigma_baseline (float): The standard deviation of the log-normal distribution for the baseline group.
        mu_treatment (float): The mean of the log-normal distribution for the treatment group.
        sigma_treatment (float): The standard deviation of the log-normal distribution for the treatment group.
        num_samples_treatment (int): The number of samples in the treatment group.
        num_samples_baseline (int): The number of samples in the baseline group.
    """
    def __init__(self, total_samples, proportion_treated, baseline_mu, baseline_sigma, treatment_mu, treatment_sigma):
        """
        Initialize the LogNormalDistribution class with the given parameters.

        Args:
            total_samples (int): The total number of samples in the experiment.
            proportion_treated (float): The proportion of samples in the treatment group.
            mu_baseline (float): The mean of the log-normal distribution for the baseline group.
            sigma_baseline (float): The standard deviation of the log-normal distribution for the baseline group.
            mu_treatment (float): The mean of the log-normal distribution for the treatment group.
            sigma_treatment (float): The standard deviation of the log-normal distribution for the treatment group.
        """
        super().__init__(total_samples, proportion_treated)
        self.baseline_mu = baseline_mu
        self.baseline_sigma = baseline_sigma
        self.treatment_mu = treatment_mu
        self.treatment_sigma = treatment_sigma

    def simulate_data(self):
        """
        Simulate log-normal data for the baseline and treatment groups using the specified parameters.

        Returns:
            tuple: A tuple containing two NumPy arrays, one for the baseline data and one for the treatment data.
        """
        baseline_data = np.random.lognormal(mean=self.baseline_mu, sigma=self.baseline_sigma, size=self.num_samples_baseline)
        treatment_data = np.random.lognormal(mean=self.treatment_mu, sigma=self.treatment_sigma, size=self.num_samples_treatment)
        return baseline_data, treatment_data

    def analysis(self, baseline_data, treatment_data, prior_mu_baseline=0, prior_nu_baseline=1, prior_alpha_baseline=1, prior_beta_baseline=1,
                          prior_mu_treatment=0, prior_nu_treatment=1, prior_alpha_treatment=1, prior_beta_treatment=1):
        """
        Perform Bayesian analysis on log-normal data using a Normal-Gamma conjugate prior.

        Given the observed data for the baseline and treatment groups, update the prior
        distribution with the observed data to obtain the posterior
        distribution for each group.

        Args:
            baseline_data (array-like): Log-normal data for the baseline group.
            treatment_data (array-like): Log-normal data for the treatment group.
            prior_mu (float): The prior mean for the normal distribution, defaults to 0.
            prior_nu (float): The prior number of observations for the normal distribution, defaults to 1.
            prior_alpha (float): The prior shape parameter for the gamma distribution, defaults to 1.
            prior_beta (float): The prior scale parameter for the gamma distribution, defaults to 1.

        Returns:
            tuple: A tuple containing the posterior distributions (as tuples of mu, nu, alpha, and beta parameters)
                   for the baseline and treatment groups.
        """
        # Bayesian analysis for baseline
        n_baseline = len(baseline_data)
        x_bar_baseline = np.mean(baseline_data)
        s2_baseline = np.var(baseline_data, ddof=1)

        posterior_mu_baseline = (prior_nu_baseline * prior_mu_baseline + n_baseline * x_bar_baseline) / (prior_nu_baseline + n_baseline)
        posterior_nu_baseline = prior_nu_baseline + n_baseline
        posterior_alpha_baseline = prior_alpha_baseline + n_baseline / 2
        posterior_beta_baseline = prior_beta_baseline + 0.5 * (n_baseline * s2_baseline + (prior_nu_baseline * n_baseline * (x_bar_baseline - prior_mu_baseline)**2) / (prior_nu_baseline + n_baseline))

        # Bayesian analysis for treatment
        n_treatment = len(treatment_data)
        x_bar_treatment = np.mean(treatment_data)
        s2_treatment = np.var(treatment_data, ddof=1)

        posterior_mu_treatment = (prior_nu_treatment * prior_mu_treatment + n_treatment * x_bar_treatment) / (prior_nu_treatment + n_treatment)
        posterior_nu_treatment = prior_nu_treatment + n_treatment
        posterior_alpha_treatment = prior_alpha_treatment + n_treatment / 2
        posterior_beta_treatment = prior_beta_treatment + 0.5 * (n_treatment * s2_treatment + (prior_nu_treatment * n_treatment * (x_bar_treatment - prior_mu_treatment)**2) / (prior_nu_treatment + n_treatment))

        return (posterior_mu_baseline, posterior_nu_baseline, posterior_alpha_baseline, posterior_beta_baseline), (posterior_mu_treatment, posterior_nu_treatment, posterior_alpha_treatment, posterior_beta_treatment)

    def calculate_credible_interval(self, posterior, alpha=0.9):
        """
        Calculate the credible interval for the given Normal-Gamma posterior distribution and alpha level.

        Args:
            posterior (tuple): The posterior distribution as a tuple (mu, nu, alpha, beta).
            alpha (float): The alpha level for the credible interval, default is 0.9 for a 90% interval.

        Returns:
            tuple: The lower and upper bounds of the credible interval for the posterior.
        """
        posterior_mu, posterior_nu, posterior_alpha, posterior_beta = posterior
        sigma_squared_lower, sigma_squared_upper = invgamma.interval(alpha, posterior_alpha, scale=posterior_beta)

        t_alpha = t.ppf((1 + alpha) / 2, 2 * posterior_alpha)
        sqrt_nu_over_nu_plus1 = np.sqrt(posterior_nu / (posterior_nu + 1))

        lower_bound = posterior_mu - sqrt_nu_over_nu_plus1 * np.sqrt(sigma_squared_upper) * t_alpha
        upper_bound = posterior_mu + sqrt_nu_over_nu_plus1 * np.sqrt(sigma_squared_upper) * t_alpha

        return lower_bound, upper_bound
