import numpy as np
from scipy.stats import t
from abstract_distribution import AbstractDistribution



class NormalDistribution(AbstractDistribution):
    """
    A subclass of AbstractDistribution for Bayesian A/B testing using Normal distributions.

    Attributes:
        total_samples (int): The total number of samples.
        proportion_treated (float): The proportion of samples in the treatment group.
        baseline_mean (float): The mean of the baseline Normal distribution.
        expected_lift (float): The expected lift in the treatment group relative to the baseline group.
    """

    def __init__(self, total_samples, proportion_treated, baseline_mean, expected_lift):
        super().__init__(total_samples, proportion_treated)
        self.baseline_mean = baseline_mean
        self.treatment_mean = baseline_mean * (1 + expected_lift)

    def simulate_data(self):
        """
        Simulate data for the baseline and treatment groups using the specified Normal distributions.

        Returns:
            tuple: A tuple containing the simulated data for the baseline and treatment groups.
        """
        baseline_data = np.random.normal(loc=self.baseline_mean, scale=1, size=self.num_samples_baseline)
        treatment_data = np.random.normal(loc=self.treatment_mean, scale=1, size=self.num_samples_treatment)
        return baseline_data, treatment_data

    def analysis(self, baseline_data, treatment_data, prior_mu=0, prior_nu=1, prior_alpha=1, prior_beta=1):
        """
        Perform Bayesian analysis on the simulated data using a Normal-Gamma conjugate prior.

        Args:
            baseline_data (array-like): The simulated data for the baseline group.
            treatment_data (array-like): The simulated data for the treatment group.
            prior_mu (float): The prior mean, default is 0.
            prior_nu (float): The prior number of observations, default is 1.
            prior_alpha (float): The prior shape parameter, default is 1.
            prior_beta (float): The prior scale parameter, default is 1.

        Returns:
            tuple: A tuple containing the posterior distributions for the baseline and treatment groups.
        """
        n_baseline = len(baseline_data)
        n_treatment = len(treatment_data)

        xbar_baseline = np.mean(baseline_data)
        xbar_treatment = np.mean(treatment_data)

        s2_baseline = np.var(baseline_data, ddof=1)
        s2_treatment = np.var(treatment_data, ddof=1)

        posterior_nu_baseline = prior_nu + n_baseline
        posterior_nu_treatment = prior_nu + n_treatment

        posterior_mu_baseline = (prior_nu * prior_mu + n_baseline * xbar_baseline) / posterior_nu_baseline
        posterior_mu_treatment = (prior_nu * prior_mu + n_treatment * xbar_treatment) / posterior_nu_treatment

        posterior_alpha_baseline = prior_alpha + n_baseline / 2
        posterior_alpha_treatment = prior_alpha + n_treatment / 2

        posterior_beta_baseline = prior_beta + 0.5 * n_baseline * s2_baseline + (
            n_baseline * prior_nu * (xbar_baseline - prior_mu) ** 2) / (2 * posterior_nu_baseline)
        posterior_beta_treatment = prior_beta + 0.5 * n_treatment * s2_treatment + (
            n_treatment * prior_nu * (xbar_treatment - prior_mu) ** 2) / (2 * posterior_nu_treatment)

        return (posterior_mu_baseline, posterior_nu_baseline, posterior_alpha_baseline, posterior_beta_baseline), \
                (posterior_mu_treatment, posterior_nu_treatment, posterior_alpha_treatment, posterior_beta_treatment)

    def calculate_credible_interval(self, posterior, alpha=0.9):
        """
        Calculate the credible interval for the given Normal-Gamma posterior distribution and alpha level.

        Args:
            posterior (tuple): The posterior distribution as a tuple (mu, nu, alpha, beta).
            alpha (float): The alpha level for the credible interval, default is 0.9 for a 90% interval.

        Returns:
            tuple: The lower and upper bounds of the credible interval for the posterior mean.
        """
        posterior_mu, posterior_nu, posterior_alpha, posterior_beta = posterior
        student_t = t(df=2 * posterior_alpha)

        # Calculate the standard deviation of the posterior mean
        posterior_std_dev = np.sqrt(posterior_beta * (posterior_nu + 1) / (posterior_alpha * posterior_nu))

        # Calculate the margin of error for the given alpha level
        margin_of_error = student_t.ppf((1 + alpha) / 2) * posterior_std_dev

        # Calculate the credible interval for the posterior mean
        lower_bound = posterior_mu - margin_of_error
        upper_bound = posterior_mu + margin_of_error

        return lower_bound, upper_bound
